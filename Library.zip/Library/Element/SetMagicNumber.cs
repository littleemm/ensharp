﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Library
{
    class SetMagicNumber
    {
        public const int NORETURN = 0;
    }
}
